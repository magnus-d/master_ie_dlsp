import uos

files = uos.listdir()
print("Imported files: ", files, "\n")
